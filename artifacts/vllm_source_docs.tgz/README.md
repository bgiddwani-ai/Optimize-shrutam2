# Optimize Shrutam-2

Measured server/client optimization of `bharatgenai/Shrutam-2` on GPU 0 of
`minimum-fuchsia-mule`. The maximum-throughput deployment now keeps the BF16
FastConformer/SMEAR frontend in the API process and serves the fine-tuned Llama
decoder through vLLM continuous batching. It adds adaptive length-aware
frontend batches, persistent client streams, and an extended server keep-alive.
The earlier compiled four-beam path remains the quality-oriented alternative.

All requested matrices completed with zero failed requests in the final runs.
Raw request records, health responses, server batch counters, GPU telemetry,
accuracy pairs, build logs, and checksums are under `results/`, `logs/`, and
`artifacts/`.

## Reproduced environment

| Item | Value |
|---|---|
| Brev instance | `minimum-fuchsia-mule` |
| Benchmark GPU | GPU 0, NVIDIA H100 NVL, 95,830 MiB |
| Driver | 595.71.05 |
| Shrutam-2 revision | `e249bba6f7319c27912847fbbebb4258ead3b848` |
| Baseline-code revision | `93586a8d949d364f26c600e2f5213a9cdccf69aa` |
| Canary/vLLM reference revision | `ae29af4502c9ac52eb88dbbbd6df721e4d8cac82` |
| vLLM / PyTorch | vLLM 0.12.0 / PyTorch 2.9.1+cu129 |
| HTTP runtime image | `shrutam2-runtime:25.02`, based on `nvcr.io/nvidia/nemo:25.02` |
| TensorRT-LLM image | `nvcr.io/nvidia/tensorrt-llm/release:0.20.0` |
| TensorRT engine builder | TensorRT 10.10.0.31 |
| HTTP image TensorRT | TensorRT 10.8.0.24 |
| Data | 46 IndicVoices clips, 12 supported languages, 16 kHz |

GPU 0 was isolated for these runs. GPU 1 continued to host an unrelated Indic
Flex service and was never selected by the Shrutam containers.

## Measurement definition

End-to-end RTFx is:

```text
sum(valid input audio seconds) / client wall-clock seconds
```

It includes request upload on an already-established HTTP connection, server queueing, log-mel preprocessing,
Conformer, SMEAR projection, autoregressive Llama decoding, and response
parsing. File loading, PCM conversion, and connection establishment are outside
the timed interval, matching a persistent server/client deployment. The client
preconnects up to 256 logical streams; c512 reuses that pool and opens any
additional sockets as needed. The exact-1-second matrix trims or zero-pads each
request to exactly 16,000 samples. Concurrency is client concurrency, not an
assertion that the engine saw the same batch size. Actual microbatches are
recorded in each `server_stats.json`; the adaptive frontend uses batch 32 or 64,
a 5 ms low-load window, and a 50 ms high-load gather window.

Encoder-only RTFx is explicitly separated because it excludes HTTP,
preprocessing, SMEAR, and Llama decoding. TensorRT `trtexec` values use GPU
compute time, CUDA graphs, disabled host transfers, 100 timed iterations, and
exact-1-second shapes.

## Install

All remote work was performed in persistent GNU screen sessions.

```bash
brev shell minimum-fuchsia-mule
screen -S shrutam2_work
mkdir -p /home/nvidia/Optimize-shrutam2
cd /home/nvidia/Optimize-shrutam2
```

Copy this directory to the instance, then build the pinned runtime:

```bash
bash build_runtime.sh
```

Download the pinned model snapshot. No token is required for the currently
public repository; if access policy changes, authenticate on the host without
putting a token into a command or log.

```bash
docker run --rm -v "$PWD:/workspace" nvcr.io/nvidia/nemo:25.02 \
  huggingface-cli download bharatgenai/Shrutam-2 \
  --revision e249bba6f7319c27912847fbbebb4258ead3b848 \
  --local-dir /workspace/model
```

Expected checkpoint hashes are retained in `logs/model_sha256.txt`.

## Prepare the quick dataset

The measured manifest was recovered from cached IndicVoices Arrow data because
the source audio/reference pairs already existed on this host:

```bash
docker run --rm \
  -v /home/nvidia/.cache:/host_cache:ro \
  -v "$PWD:/workspace" -w /workspace shrutam2-runtime:25.02 \
  python prepare_cached_indicvoices.py \
    --cache-root /host_cache/huggingface/datasets/parquet \
    --output-dir /workspace/data/indicvoices_quick \
    --samples-per-language 4
```

The resulting manifest has 46 unique clips across Assamese, Bengali, Gujarati,
Hindi, Kannada, Malayalam, Marathi, Odia, Punjabi, Tamil, Telugu, and Urdu.

## Install and run the maximum-throughput vLLM server/client

The vLLM path was inspired by the Canary/Qwen separation in
[wuxuedaifu/Canary-Qwen-2.5b-vllm](https://github.com/wuxuedaifu/Canary-Qwen-2.5b-vllm):
compute audio prompt embeddings in the ASR frontend, then let vLLM continuously
batch independent decoder requests.

```bash
sudo apt-get update
sudo apt-get install -y python3.12-venv

mkdir -p baseline
git clone https://github.com/wuxuedaifu/Canary-Qwen-2.5b-vllm \
  baseline/Canary-Qwen-2.5b-vllm
git -C baseline/Canary-Qwen-2.5b-vllm checkout \
  ae29af4502c9ac52eb88dbbbd6df721e4d8cac82

bash install_vllm.sh
source .venv-vllm/bin/activate
python export_vllm_checkpoint.py
python smoke_vllm_prompt_embeds.py \
  --model-dir artifacts/vllm_llm_bf16 \
  --output artifacts/vllm_prompt_embed_smoke.json
```

The export step is mandatory: `model/model.pt` contains 147 fine-tuned
`llm.*` tensors. Pointing vLLM at the released base `model/llm` directory
instead produced 272% WER. The exported BF16 decoder contains 146 expected
tensors and is checksummed in `artifacts/vllm_llm_bf16/export_report.json`.

Start and benchmark in separate persistent remote screen sessions:

```bash
screen -L -Logfile logs/server_vllm_adaptive_final_screen.log \
  -dmS shrutam2_vllm_server bash -lc \
  'cd /home/nvidia/Optimize-shrutam2; ./start_server_vllm.sh'

until curl -fsS http://127.0.0.1:8092/health; do sleep 2; done

screen -L -Logfile logs/run_vllm_adaptive_final_screen.log \
  -dmS shrutam2_vllm_bench bash -lc \
  'cd /home/nvidia/Optimize-shrutam2; ./run_vllm_benchmarks.sh'

tail -f logs/run_vllm_adaptive_final_screen.log
screen -S shrutam2_vllm_server -X quit
```

The launcher deploys GPU 0 only: eager BF16 FastConformer/SMEAR, vLLM BF16
with CUDA graphs and chunked prefill, 512 decoder sequences, adaptive 32/64
frontend microbatches, a 256-request length lookahead, and 120-second HTTP
keep-alive. `benchmark_client.py` rejects empty/invalid responses and records
every latency, transcript, generated-token count, batch size, and retry count.

## Run the quality-oriented HTTP server/client benchmark

```bash
RUNTIME=compile PRECISION=bf16 NUM_BEAMS=4 MAX_NEW_TOKENS=200 \
  bash start_server.sh

VARIANT=optimized_compile_bf16_beam4 bash run_http_benchmarks.sh
bash stop_server.sh
```

`start_server.sh` persists the Inductor cache in
`artifacts/torchinductor_cache`. Its readiness gate includes warm-up batches
before clients are admitted. `run_http_benchmarks.sh` executes:

- variable-duration concurrency `1,2,8,32,64,128,256`;
- exact-1-second concurrency `1,2,8,32,64,128,256,512`;
- sequential transcript capture and WER/CER calculation.

For the maximum-throughput, lower-accuracy profile:

```bash
RUNTIME=eager PRECISION=bf16 NUM_BEAMS=1 MAX_NEW_TOKENS=96 bash start_server.sh
VARIANT=optimized_eager_bf16_beam1 bash run_http_benchmarks.sh
bash stop_server.sh
```

## End-to-end HTTP results

RTFx, variable-duration audio:

| Variant | c1 | c2 | c8 | c32 | c64 | c128 | c256 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Upstream FP32 Conformer, BF16 LLM, beam 4 | 16.16 | 19.72 | 38.16 | 78.02 | 99.93 | 97.46 | 138.31 |
| Compiled BF16, beam 4 | 19.09 | 26.80 | 47.79 | 101.67 | 115.37 | 113.69 | 120.53 |
| Eager BF16, beam 1 throughput profile | 22.22 | 29.55 | 32.49 | 89.95 | 116.87 | 132.80 | 183.37 |
| **vLLM adaptive persistent, BF16 beam 1** | **32.96** | **57.41** | **97.49** | **164.22** | **314.13** | **423.81** | **550.85** |

RTFx, exact-1-second audio:

| Variant | c1 | c2 | c8 | c32 | c64 | c128 | c256 | c512 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Upstream FP32 Conformer, BF16 LLM, beam 4 | 9.54 | 24.41 | 46.94 | 90.67 | 73.98 | 84.66 | 48.61 | 83.60 |
| Compiled BF16, beam 4 | 15.30 | 16.82 | 40.17 | 76.44 | 101.55 | 49.77 | 47.56 | 68.03 |
| Eager BF16, beam 1 throughput profile | **17.20** | **28.94** | **53.55** | **120.79** | **117.56** | **92.05** | 48.49 | 73.61 |
| **vLLM adaptive persistent, BF16 beam 1** | 12.56 | 21.12 | 51.25 | 98.01 | 111.85 | **112.91** | **119.98** | **95.59** |

The vLLM row is a single cohesive final run. Against the earlier eager BF16
beam-1 path, variable-duration RTFx improved by 1.48x, 1.94x, 3.00x, 1.83x,
2.69x, 3.19x, and 3.00x at c1 through c256. Exact-1-second throughput favors
the old path below c128, but vLLM improves c128/c256/c512 by 1.23x/2.47x/1.30x.
The bold cells are the highest measured value in each column, not a claim of
statistical significance. Every final vLLM cell had zero failures; all 1,792
timed matrix responses completed on their first transport attempt.

The upstream c256 variable run initially had one transport `ReadError` and was
excluded. The table uses the clean 256/256 retry at 138.31 RTFx; both runs are
retained in the artifacts.

## Quick accuracy

| Path | Beams | WER | CER | WER change vs upstream |
|---|---:|---:|---:|---:|
| Upstream FP32 Conformer + BF16 LLM | 4 | 29.412% | 17.334% | — |
| **Compiled BF16 end-to-end** | 4 | **29.630%** | **17.522%** | **+0.218 pp** |
| Eager BF16 throughput profile | 1 | 32.462% | 19.918% | +3.050 pp |
| vLLM adaptive persistent throughput profile | 1 | 31.808% | 18.233% | +2.396 pp |

The 46-clip set is a quick regression check, not a publication-grade model
evaluation. The compiled BF16 profile is the recommended result because it
keeps the same four-beam search and changes WER by only 0.218 percentage
points. The vLLM profile is clearly labeled throughput-only, but it improves
the earlier one-beam quick WER by 0.654 percentage points while delivering the
largest throughput gains. Its matrix generated-token maximum was 49, below the
configured limit of 96, so no measured response was truncated by that limit.

## Conformer encoder optimization

Build and test the BF16 ONNX/TensorRT engine:

```bash
docker run --rm --gpus device=0 --ipc=host -v "$PWD:/workspace" \
  -w /workspace shrutam2-runtime:25.02 \
  python export_encoder_onnx.py --model-dir /workspace/model

docker run --rm --gpus device=0 --ipc=host -v "$PWD:/workspace" \
  -w /workspace nvcr.io/nvidia/tensorrt-llm/release:0.20.0 \
  bash build_trt_encoder.sh

bash benchmark_trtexec.sh
```

For FP16, export FP32 ONNX weights and set `PRECISION=fp16`, `ENGINE`, and
`CACHE` when invoking `build_trt_encoder.sh`; the exact command is preserved in
`logs/trt_encoder_fp16_build.log`.

Build the AOTInductor package and run the exact-shape comparison:

```bash
docker run --rm --gpus device=0 --ipc=host -v "$PWD:/workspace" \
  -w /workspace shrutam2-runtime:25.02 \
  python export_encoder_aoti.py \
    --model-dir /workspace/model \
    --static-frames 101 --max-batch 256 \
    --output /workspace/artifacts/shrutam2_encoder_bf16_1s.pt2 \
    --report /workspace/artifacts/aoti_1s_build_report.json

bash run_encoder_1s.sh
```

Exact-1-second encoder-only RTFx:

| Runtime | b1 | b2 | b8 | b32 | b64 | b128 | b256 |
|---|---:|---:|---:|---:|---:|---:|---:|
| PyTorch eager BF16 | 41.51 | 80.97 | 321.20 | 1202.14 | 2484.56 | 3832.08 | 4408.51 |
| `torch.compile` BF16 | 267.24 | 393.33 | 1348.75 | 5030.27 | 4054.32 | 4630.07 | 4989.11 |
| AOTI BF16, static time | 240.27 | 412.79 | 1396.80 | 5198.26 | 4199.20 | 4845.45 | 5205.14 |
| TensorRT BF16 `trtexec` | 224.43 | 444.75 | 1692.17 | 5295.66 | — | — | — |
| TensorRT FP16 `trtexec` | 266.14 | 531.42 | 2054.05 | **7128.30** | — | — | — |

The TensorRT plan profile is capped at batch 32 because that is the HTTP
server's real microbatch ceiling. Full dynamic-time AOTI export failed on
symbolic divisibility guards introduced by the 8x convolutional subsampler, so
the valid AOTI artifact is deliberately static in time (101 mel frames) and
dynamic only in batch.

The TensorRT engines were built with TensorRT 10.10, but the NeMo 25.02 HTTP
image contains TensorRT 10.8 and cannot deserialize them. Consequently these
TensorRT numbers are encoder-stage `trtexec` evidence, not end-to-end HTTP ASR
results. Use a single TensorRT 10.10 runtime image before selecting
`RUNTIME=trt` in production.

## TensorRT-LLM BF16 and ModelOpt FP8

Shrutam-2 passes projected audio vectors directly to Llama as prefix
embeddings. The engine must therefore enable a prompt-embedding table; a
text-only decoder smoke test is not valid evidence for this model.

```bash
bash probe_trtllm.sh
bash build_trtllm_llm.sh

docker run --rm --gpus device=0 --ipc=host \
  -e HF_HUB_OFFLINE=1 -e TRANSFORMERS_OFFLINE=1 \
  -v "$PWD:/workspace" -w /workspace \
  nvcr.io/nvidia/tensorrt-llm/release:0.20.0 \
  python trtllm_audio_smoke.py \
    --model-dir /workspace/model \
    --engine-dir /workspace/artifacts/trtllm_llm_bf16_engine \
    --manifest /workspace/data/indicvoices_quick/manifest.jsonl \
    --output /workspace/results/trtllm_bf16/accuracy_requests_beam4.jsonl \
    --max-new-tokens 200 --num-beams 4

bash build_modelopt_fp8_llm.sh
```

The real-audio prompt-table accuracy results were:

| Decoder engine | WER | CER | FP8 minus BF16 WER |
|---|---:|---:|---:|
| TensorRT-LLM BF16, beam 4 | 31.808% | 18.308% | — |
| TensorRT-LLM ModelOpt FP8 + FP8 KV, beam 4 | 30.719% | 16.061% | -1.089 pp |

FP8 produced no directional WER regression. However, the absolute WER movement
is 1.089 percentage points, narrowly outside a strict `abs(FP8-BF16) < 1 pp`
equivalence rule. The ModelOpt engine and evidence are retained as exploratory,
but this README does not promote it as strict quality-equivalent on such a
small set. Re-run on a larger, fixed evaluation manifest before deployment.

## Result map

- `results/consolidated_results.json`: machine-readable tables and pass/fail
  validation for all eight HTTP matrices.
- `results/vllm_continuous_bf16_adaptive_persistent_beam1/`: the promoted
  vLLM variable, exact-1-second, quick-accuracy, and server-stat evidence.
- `artifacts/provenance.json`: host, revisions, and SHA-256 hashes for every
  large engine/package.
- `results/*/*/requests.jsonl`: per-request latency and transcript evidence.
- `results/*/*/server_stats.json`: actual dynamic-batch histograms.
- `logs/`: complete build, server, client, accuracy, GPU, and failure logs.
- `LEARNIGS.md`: implementation decisions, failures, and boundaries.

Large ONNX, AOTI, TensorRT, and TensorRT-LLM binaries are not duplicated in the
local evidence bundle. Their byte sizes and hashes are recorded in
`artifacts/provenance.json`, and all build scripts needed to reproduce them are
included here.
