#!/usr/bin/env python3
"""Merge the promoted vLLM run into the existing consolidated evidence."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
VARIANT = "vllm_continuous_bf16_adaptive_persistent_beam1"


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def validate(rows: list[dict], expected: list[int]) -> dict:
    by_concurrency = {int(row["concurrency"]): row for row in rows}
    missing = sorted(set(expected) - set(by_concurrency))
    failures = {
        str(value): int(by_concurrency[value].get("failed", 0))
        for value in expected
        if value in by_concurrency and int(by_concurrency[value].get("failed", 0))
    }
    return {
        "expected": expected,
        "missing": missing,
        "failures": failures,
        "passed": not missing and not failures,
    }


def improvement(current: list[dict], baseline: list[dict]) -> list[dict]:
    base = {int(row["concurrency"]): float(row["rtfx"]) for row in baseline}
    return [
        {
            "concurrency": int(row["concurrency"]),
            "rtfx_ratio": float(row["rtfx"]) / base[int(row["concurrency"])],
        }
        for row in current
    ]


def main() -> None:
    consolidated_path = RESULTS / "consolidated_results.json"
    report = read_json(consolidated_path)
    directory = RESULTS / VARIANT
    variable = read_json(directory / "variable" / "summary.json")
    chunk = read_json(directory / "chunk_1s" / "summary.json")
    accuracy = read_json(directory / "quick_accuracy.json")
    stats = read_json(directory / "server_stats_final.json")

    eager = report["http_server_client"]["throughput_profile_eager_bf16_beam1"]
    report["measurement"]["vllm_transport"] = (
        "PCM conversion and persistent-stream connection establishment are untimed; "
        "timing starts immediately before the request wave and ends after every response"
    )
    report["http_server_client"]["vllm_adaptive_persistent_bf16_beam1"] = {
        "variant": VARIANT,
        "variable": variable,
        "chunk_1s": chunk,
        "accuracy": accuracy,
        "server_stats_final": stats,
        "improvement_vs_eager_bf16_beam1": {
            "variable": improvement(variable, eager["variable"]),
            "chunk_1s": improvement(chunk, eager["chunk_1s"]),
        },
    }
    report["matrix_validation"]["vllm_variable"] = validate(
        variable, [1, 2, 8, 32, 64, 128, 256]
    )
    report["matrix_validation"]["vllm_chunk_1s"] = validate(
        chunk, [1, 2, 8, 32, 64, 128, 256, 512]
    )

    consolidated_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "results": str(consolidated_path),
        "variable_passed": report["matrix_validation"]["vllm_variable"]["passed"],
        "chunk_1s_passed": report["matrix_validation"]["vllm_chunk_1s"]["passed"],
    }))


if __name__ == "__main__":
    main()
